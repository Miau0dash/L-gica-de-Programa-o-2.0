/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio1.pkg0;

/**
 *
 * @author aluno
 */
public class Exercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Escola escola = new Escola(); 
        escola.cadastrarAluno(); 
        escola.exibirResultadoAluno(); 
    }
    
}
